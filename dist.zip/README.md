# weatherapp-darksky-express-node
this is a weather app designed with express node and darksky api
