// function {updateWeatherInfo, } = require ('./node_modules')

// test('', () =>{
//     expect(function(var1, var2)).toBe(var3)
// })